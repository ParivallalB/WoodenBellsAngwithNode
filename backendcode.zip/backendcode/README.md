Node-Mailer
===========

Node.js Script to send e-mail's.

To read how to use it visit http://www.codeforgeek.com.
