var express=require('express');
var bodyParser = require('body-parser');
var nodemailer = require("nodemailer");
var cors = require('cors');
var path=require('path');
var app=express();

app.use(cors());
const PORT=process.env.PORT ||8080;
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));
 
// parse application/json
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname,'public')));

app.get('*',(req,res)=>{
	res.sendFile(path.json(__dirname,'public/index.html'));
})

app.get('/',(req,res)=>{
	res.sendFile(path.json(__dirname,'public/index.html'));
})
var smtpTransport = nodemailer.createTransport({
    service: 'gmail',
    host: 'smtp.gmail.com',
    port: 587,
    auth: {
        user: 'clientusermail005@gmail.com',
        pass: 'Welcome@123'
    },
    tls: {rejectUnauthorized: false},
    debug:true
});
app.post('/send',function(req,res){
	var mailOptions={
		from:req.body.from,
		to :"woodenbells@yahoo.com",
		subject :req.body.subject+ " " + req.body.from +" "+ req.body.phone,
		text :req.body.text
	}
	console.log(mailOptions);
	smtpTransport.sendMail(mailOptions, function(error, response){
   	 if(error){
        	console.log(error);
		res.end("error");
	 }else{
        	console.log("Message sent: " + response.message);
		res.end("sent");
    	 }
});
});

/*--------------------Routing Over----------------------------*/

app.listen(PORT,function(){
	console.log("Express Started on Port "+PORT);
});
