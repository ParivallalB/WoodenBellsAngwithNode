(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/about/about.component.css":
/*!*******************************************!*\
  !*** ./src/app/about/about.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/about/about.component.html":
/*!********************************************!*\
  !*** ./src/app/about/about.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- banner-2 -->\n<div class=\"page-head_agile_info_w3l about\">\n</div>\n<!-- //banner-2 -->\n<!-- page -->\n<div class=\"services-breadcrumb\">\n  <div class=\"agile_inner_breadcrumb\">\n    <div class=\"container\">\n      <ul class=\"w3_short\">\n        <li>\n          <a routerLink=\"/\">Home</a>\n          <i>|</i>\n        </li>\n        <li>About Us</li>\n      </ul>\n    </div>\n  </div>\n</div>\n<!-- //page -->\n<div class=\"welcome\">\n  <div class=\"container\">\n    <!-- tittle heading -->\n    <h3 class=\"tittle-w3l\">About Us\n      <span class=\"heading-style\">\n        <i></i>\n        <i></i>\n        <i></i>\n      </span>\n    </h3>\n    <!-- //tittle heading -->\n    <!-- <div class=\"w3l-welcome-info\">\n      <div class=\"col-sm-6 col-xs-6 welcome-grids\">\n        <div class=\"welcome-img\">\n          <img src=\"../../assets/images/logo2.jpg\" class=\"img-responsive zoom-img\" alt=\"\">\n        </div>\n      </div>\n      <div class=\"col-sm-6 col-xs-6 welcome-grids\">\n        <div class=\"welcome-img\">\n          <img src=\"../../assets/images/logo.jpg\" class=\"img-responsive zoom-img\" alt=\"\">\n        </div>\n      </div>\n      <div class=\"clearfix\"> </div>\n    </div> -->\n    <div class=\"w3l-welcome-text\">\n      <p> Wooden bells has a fully automated production system with precision machinery which allows us to provide high quality perfect modular furniture and interiors. Different Styles can also be customized to the size and comfort based on our customer’s desire by using advanced technologies and superior.\n        </p>\n        <p>We will understand your requirements and will provide you with solutions that perfectly suit your needs and preferences.Whether you are looking for modern, classic or theme based designs, we offer the best solutions for all your needs.\n          </p>\n      \n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/about/about.component.ts":
/*!******************************************!*\
  !*** ./src/app/about/about.component.ts ***!
  \******************************************/
/*! exports provided: AboutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutComponent", function() { return AboutComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AboutComponent = /** @class */ (function () {
    function AboutComponent() {
    }
    AboutComponent.prototype.ngOnInit = function () {
    };
    AboutComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-about',
            template: __webpack_require__(/*! ./about.component.html */ "./src/app/about/about.component.html"),
            styles: [__webpack_require__(/*! ./about.component.css */ "./src/app/about/about.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], AboutComponent);
    return AboutComponent;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-topnavbar></app-topnavbar>\n<router-outlet></router-outlet>\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'app';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var angular_image_slider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular-image-slider */ "./node_modules/angular-image-slider/esm5/angular-image-slider.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _topnavbar_topnavbar_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./topnavbar/topnavbar.component */ "./src/app/topnavbar/topnavbar.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _about_about_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./about/about.component */ "./src/app/about/about.component.ts");
/* harmony import */ var _service_service_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./service/service.component */ "./src/app/service/service.component.ts");
/* harmony import */ var _contact_contact_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./contact/contact.component */ "./src/app/contact/contact.component.ts");
/* harmony import */ var _app_route__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./app.route */ "./src/app/app.route.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var _app_emailservices_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../app/emailservices.service */ "./src/app/emailservices.service.ts");
/* harmony import */ var _products_products_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./products/products.component */ "./src/app/products/products.component.ts");
/* harmony import */ var _productstables_productstables_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./productstables/productstables.component */ "./src/app/productstables/productstables.component.ts");
/* harmony import */ var _productscots_productscots_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./productscots/productscots.component */ "./src/app/productscots/productscots.component.ts");
/* harmony import */ var _productswallshelves_productswallshelves_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./productswallshelves/productswallshelves.component */ "./src/app/productswallshelves/productswallshelves.component.ts");
/* harmony import */ var _products_bookshelf_products_bookshelf_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./products-bookshelf/products-bookshelf.component */ "./src/app/products-bookshelf/products-bookshelf.component.ts");
/* harmony import */ var _products_shoeracks_products_shoeracks_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./products-shoeracks/products-shoeracks.component */ "./src/app/products-shoeracks/products-shoeracks.component.ts");
/* harmony import */ var _products_wardrobes_products_wardrobes_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./products-wardrobes/products-wardrobes.component */ "./src/app/products-wardrobes/products-wardrobes.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};























var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"],
                _topnavbar_topnavbar_component__WEBPACK_IMPORTED_MODULE_7__["TopnavbarComponent"],
                _home_home_component__WEBPACK_IMPORTED_MODULE_8__["HomeComponent"],
                _about_about_component__WEBPACK_IMPORTED_MODULE_9__["AboutComponent"],
                _service_service_component__WEBPACK_IMPORTED_MODULE_10__["ServiceComponent"],
                _contact_contact_component__WEBPACK_IMPORTED_MODULE_11__["ContactComponent"],
                _footer_footer_component__WEBPACK_IMPORTED_MODULE_14__["FooterComponent"],
                _products_products_component__WEBPACK_IMPORTED_MODULE_16__["ProductsComponent"],
                _productstables_productstables_component__WEBPACK_IMPORTED_MODULE_17__["ProductstablesComponent"],
                _productscots_productscots_component__WEBPACK_IMPORTED_MODULE_18__["ProductscotsComponent"],
                _productswallshelves_productswallshelves_component__WEBPACK_IMPORTED_MODULE_19__["ProductswallshelvesComponent"],
                _products_bookshelf_products_bookshelf_component__WEBPACK_IMPORTED_MODULE_20__["ProductsBookshelfComponent"],
                _products_shoeracks_products_shoeracks_component__WEBPACK_IMPORTED_MODULE_21__["ProductsShoeracksComponent"],
                _products_wardrobes_products_wardrobes_component__WEBPACK_IMPORTED_MODULE_22__["ProductsWardrobesComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["BrowserAnimationsModule"],
                angular_image_slider__WEBPACK_IMPORTED_MODULE_5__["SliderModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_13__["RouterModule"].forRoot(_app_route__WEBPACK_IMPORTED_MODULE_12__["Approute"])
            ],
            providers: [_app_emailservices_service__WEBPACK_IMPORTED_MODULE_15__["EmailservicesService"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/app.route.ts":
/*!******************************!*\
  !*** ./src/app/app.route.ts ***!
  \******************************/
/*! exports provided: Approute */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Approute", function() { return Approute; });
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _about_about_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./about/about.component */ "./src/app/about/about.component.ts");
/* harmony import */ var _service_service_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./service/service.component */ "./src/app/service/service.component.ts");
/* harmony import */ var _contact_contact_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./contact/contact.component */ "./src/app/contact/contact.component.ts");
/* harmony import */ var _products_products_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./products/products.component */ "./src/app/products/products.component.ts");
/* harmony import */ var _productstables_productstables_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./productstables/productstables.component */ "./src/app/productstables/productstables.component.ts");
/* harmony import */ var _productscots_productscots_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./productscots/productscots.component */ "./src/app/productscots/productscots.component.ts");
/* harmony import */ var _productswallshelves_productswallshelves_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./productswallshelves/productswallshelves.component */ "./src/app/productswallshelves/productswallshelves.component.ts");
/* harmony import */ var _products_bookshelf_products_bookshelf_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./products-bookshelf/products-bookshelf.component */ "./src/app/products-bookshelf/products-bookshelf.component.ts");
/* harmony import */ var _products_shoeracks_products_shoeracks_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./products-shoeracks/products-shoeracks.component */ "./src/app/products-shoeracks/products-shoeracks.component.ts");
/* harmony import */ var _products_wardrobes_products_wardrobes_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./products-wardrobes/products-wardrobes.component */ "./src/app/products-wardrobes/products-wardrobes.component.ts");











var Approute = [
    {
        path: "",
        component: _home_home_component__WEBPACK_IMPORTED_MODULE_0__["HomeComponent"]
    },
    {
        path: "about",
        component: _about_about_component__WEBPACK_IMPORTED_MODULE_1__["AboutComponent"]
    },
    {
        path: "service",
        component: _service_service_component__WEBPACK_IMPORTED_MODULE_2__["ServiceComponent"]
    },
    {
        path: "products",
        component: _products_products_component__WEBPACK_IMPORTED_MODULE_4__["ProductsComponent"]
    },
    {
        path: "productstables",
        component: _productstables_productstables_component__WEBPACK_IMPORTED_MODULE_5__["ProductstablesComponent"]
    },
    {
        path: "productscots",
        component: _productscots_productscots_component__WEBPACK_IMPORTED_MODULE_6__["ProductscotsComponent"]
    },
    {
        path: "productsWallshelves",
        component: _productswallshelves_productswallshelves_component__WEBPACK_IMPORTED_MODULE_7__["ProductswallshelvesComponent"]
    },
    {
        path: "productsBookshelf",
        component: _products_bookshelf_products_bookshelf_component__WEBPACK_IMPORTED_MODULE_8__["ProductsBookshelfComponent"]
    },
    {
        path: "productsShoeracks",
        component: _products_shoeracks_products_shoeracks_component__WEBPACK_IMPORTED_MODULE_9__["ProductsShoeracksComponent"]
    },
    {
        path: "productsWardrobes",
        component: _products_wardrobes_products_wardrobes_component__WEBPACK_IMPORTED_MODULE_10__["ProductsWardrobesComponent"]
    },
    {
        path: "contact",
        component: _contact_contact_component__WEBPACK_IMPORTED_MODULE_3__["ContactComponent"]
    },
];


/***/ }),

/***/ "./src/app/contact/contact.component.css":
/*!***********************************************!*\
  !*** ./src/app/contact/contact.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/contact/contact.component.html":
/*!************************************************!*\
  !*** ./src/app/contact/contact.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"page-head_agile_info_w3l contact\">\n\n</div>\n<!-- //banner-2 -->\n<!-- page -->\n<div class=\"services-breadcrumb\">\n  <div class=\"agile_inner_breadcrumb\">\n    <div class=\"container\">\n      <ul class=\"w3_short\">\n        <li>\n          <a routerLink=\"/\">Home</a>\n          <i>|</i>\n        </li>\n        <li>Contact Us</li>\n      </ul>\n    </div>\n  </div>\n</div>\n\n\n<div class=\"contact-w3l\">\n  <div class=\"container\">\n    <!-- tittle heading -->\n    <h3 class=\"tittle-w3l\">Contact Us\n      <span class=\"heading-style\">\n        <i></i>\n        <i></i>\n        <i></i>\n      </span>\n    </h3>\n    <!-- //tittle heading -->\n    <!-- contact -->\n    <div class=\"contact agileits\">\n      <div class=\"contact-agileinfo\">\n        <div class=\"contact-form wthree\">\n          <form #emailform =\"ngForm\" (ngSubmit)=\"onClickSubmit(emailform)\">\n              <div class=\"\">\n                  <input type=\"text\" name=\"phone\" placeholder=\"Enter Phone Number\" required=\"\" ngModel>\n                </div>\n\n              <div class=\"\">\n                  <input type=\"text\" name=\"from\" placeholder=\"Enter Your Email ID\" required=\"\" ngModel>\n                </div>\n               \n                \n            <div class=\"\">\n              <input type=\"text\" name=\"subject\" placeholder=\"Name\" required=\"\" ngModel>\n            </div>\n            \n            <div class=\"\">\n              <textarea placeholder=\"Message\" name=\"text\" required=\"\" ngModel ></textarea>\n            </div>\n            <input type=\"submit\" value=\"Submit\">\n          </form>\n        </div>\n        <div class=\"contact-right wthree\">\n          <div class=\"col-xs-7 contact-text w3-agileits contacts\">\n            <h4>GET IN TOUCH :</h4>\n            <p>\n              <i class=\"fa fa-map-marker\"></i>\n              SY no-47/P,48/P, D.no.1-6-44/1/C/NR,<br/>\n              <span>Behind hindware godown,</span><br/>\n              <span>Muthyam reddy nagar,</span> <br/>\n              <span>besides yadamma nagar,</span><br/>\n              <span>opp.kids darpan play school,</span>  <br/>\n              <span>Alwal,secunderabad, telangana-500010</span>\n            </p>\n            <p>\n              <i class=\"fa fa-user\"></i>Swapna (Director)\n            </p>\n            <p>\n              <i class=\"fa fa-phone\"></i>7674933669\n            </p>\n            <p>\n              <i class=\"fa fa-fax\"></i> FAX :</p>\n            <p>\n              <i class=\"fa fa-envelope-o\"></i>woodenbells@yahoo.com\n            </p>\n          </div>\n        \n          <div class=\"clearfix\"> </div>\n        </div>\n      </div>\n    </div>\n   \n\n  </div>\n</div>\n<!-- map -->\n<div class=\"container\">\n<div class=\"map col-xs-12\">\n\n      <iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3805.3071363531967!2d78.49344731487784!3d17.49284598801551!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTfCsDI5JzM0LjMiTiA3OMKwMjknNDQuMyJF!5e0!3m2!1sen!2sin!4v1527609920148\" frameborder=\"0\" allowfullscreen></iframe>\n</div>\n</div>"

/***/ }),

/***/ "./src/app/contact/contact.component.ts":
/*!**********************************************!*\
  !*** ./src/app/contact/contact.component.ts ***!
  \**********************************************/
/*! exports provided: ContactComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactComponent", function() { return ContactComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _emailservices_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../emailservices.service */ "./src/app/emailservices.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ContactComponent = /** @class */ (function () {
    function ContactComponent(emailservice) {
        this.emailservice = emailservice;
    }
    ContactComponent.prototype.onClickSubmit = function (emailform) {
        var newEmailList = {
            from: emailform.value.from,
            to: emailform.value.to,
            phone: emailform.value.phone,
            subject: emailform.value.subject,
            text: emailform.value.text
        };
        this.emailservice.Emailsendservices(newEmailList)
            .subscribe(function (xyz) {
            console.log(xyz);
        });
    };
    ContactComponent.prototype.ngOnInit = function () {
    };
    ContactComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-contact',
            template: __webpack_require__(/*! ./contact.component.html */ "./src/app/contact/contact.component.html"),
            styles: [__webpack_require__(/*! ./contact.component.css */ "./src/app/contact/contact.component.css")],
            providers: [_emailservices_service__WEBPACK_IMPORTED_MODULE_1__["EmailservicesService"]]
        }),
        __metadata("design:paramtypes", [_emailservices_service__WEBPACK_IMPORTED_MODULE_1__["EmailservicesService"]])
    ], ContactComponent);
    return ContactComponent;
}());



/***/ }),

/***/ "./src/app/emailservices.service.ts":
/*!******************************************!*\
  !*** ./src/app/emailservices.service.ts ***!
  \******************************************/
/*! exports provided: EmailservicesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmailservicesService", function() { return EmailservicesService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var EmailservicesService = /** @class */ (function () {
    function EmailservicesService(http) {
        this.http = http;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
        this.apiUrl = "/send";
    }
    EmailservicesService.prototype.handleError = function (error) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        }
        else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            console.error("Backend returned code " + error.status + ", " +
                ("body was: " + error.error));
        }
        // return an observable with a user-facing error message
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["throwError"])('Something bad happened; please try again later.');
    };
    ;
    EmailservicesService.prototype.Emailsendservices = function (emailfield) {
        console.log("jj" + emailfield);
        return this.http.post(this.apiUrl, emailfield, this.httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    };
    EmailservicesService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], EmailservicesService);
    return EmailservicesService;
}());



/***/ }),

/***/ "./src/app/footer/footer.component.css":
/*!*********************************************!*\
  !*** ./src/app/footer/footer.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/footer/footer.component.html":
/*!**********************************************!*\
  !*** ./src/app/footer/footer.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<footer>\n  <div class=\"container\">\n  \n    <div class=\"footer-info w3-agileits-info\">\n      \n      <div class=\"col-sm-4 address-right\">\n        <div class=\"footer-grids\">\n          <h3>Quick Links</h3>\n          <ul>\n              <li>\n                  <a routerLink=\"/\">Home</a>\n                </li>\n            <li>\n              <a routerLink=\"/about\">About Us</a>\n            </li>\n            <li>\n              <a routerLink=\"/service\">Service</a>\n            </li>\n            <li>\n                <a routerLink=\"/products\">Products</a>\n              </li>\n            <li>\n              <a routerLink=\"/contact\">Contact Us</a>\n            </li>\n           \n           \n          </ul>\n        </div>\n        </div>\n                    <div class=\"col-sm-4 address-right\">\n        <div class=\"footer-grids footercontact\">\n          <h3>Get in Touch</h3>\n          <ul>\n            <li>\n              <p>SY no-47/P,48/P, D.no.1-6-44/1/C/NR</p>\n              <p>Behind hindware godown,</p>\n              <p>Muthyam reddy nagar,</p>\n              <p>besides yadamma nagar,</p>\n              <p>opp.kids darpan play school,</p>\n              <p>Alwal,secunderabad, telangana-500010</p></li>\n           \n          </ul>\n        </div>\n      </div>\n     \n      <!-- //quick links -->\n      <!-- social icons -->\n      <div class=\"col-sm-4 address-right\">\n      <div class=\"footer-grids  w3l-socialmk\">\n        <h3>Follow Us on</h3>\n        <div class=\"social\">\n          <ul>\n            <li>\n                <a class=\"icon fb\" href=\"https://www.facebook.com/woodenbells.s.9\" target=\"_blank\">\n                  <i class=\"fa fa-facebook\"></i>\n                </a>\n           \n            </li>\n            <li>\n             \n                <a class=\"icon tw\" href=\"https://twitter.com/woodenbellss\" target=\"_blank\">\n                  <i class=\"fa fa-twitter\"></i>\n                </a>\n           \n            </li>\n            <li>\n              \n                <a class=\"icon gp\" href=\"#\"target=\"_blank\" >\n                    <i class=\"fa fa-google-plus\"></i>\n                  </a>\n            </li>\n          </ul>\n        </div>\n        </div>\n        \n      </div>\n      <!-- //social icons -->\n      <div class=\"clearfix\"></div>\n    </div>\n    \n  </div>\n</footer>\n<!-- //footer -->\n<!-- copyright -->\n<div class=\"copy-right\">\n  <div class=\"container\">\n    <p>© 2018 Wooden Bells. All rights reserved | Design by\n      <a href=\"#\"> Wooden Bells.</a>\n    </p>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.css */ "./src/app/footer/footer.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/home/home.component.css":
/*!*****************************************!*\
  !*** ./src/app/home/home.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/home/home.component.html":
/*!******************************************!*\
  !*** ./src/app/home/home.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- banner -->\n<div id=\"myCarousel\" class=\"carousel slide\" data-ride=\"carousel\">\n  <!-- Indicators-->\n  <ol class=\"carousel-indicators\">\n    <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>\n    <li data-target=\"#myCarousel\" data-slide-to=\"1\" class=\"\"></li>\n    <li data-target=\"#myCarousel\" data-slide-to=\"2\" class=\"\"></li>\n    <li data-target=\"#myCarousel\" data-slide-to=\"3\" class=\"\"></li>\n  </ol>\n  <div class=\"carousel-inner\" role=\"listbox\">\n    <div class=\"item active\">\n      <div class=\"container\">\n        <div class=\"carousel-caption\">\n          <h3>WE BUILD YOUR\n\n            <span>DREAM LIVING SPACE</span>\n          </h3>\n          \n        </div>\n      </div>\n    </div>\n    <div class=\"item item2\">\n      <div class=\"container\">\n        <div class=\"carousel-caption\">\n          <h3><span>Modular Kitchen</span>\n          </h3>\n          <p>Give an elegant look to your Kitchen \n          </p>\n          \n        </div>\n      </div>\n    </div>\n    <div class=\"item item3\">\n      <div class=\"container\">\n        <div class=\"carousel-caption\">\n          <h3><span>Wardrobes</span> \n          </h3>\n          <p>Give a new  apperance to your bedroom\n          </p>\n          \n        </div>\n      </div>\n    </div>\n    <div class=\"item item4\">\n      <div class=\"container\">\n        <div class=\"carousel-caption\">\n          <h3><span>Workstaions</span>\n          </h3>\n          \n          <p>Convert commercial space to a pleasant workplace</p>\n          \n        </div>\n      </div>\n    </div>\n  </div>\n  <a class=\"left carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"prev\">\n    <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>\n    <span class=\"sr-only\">Previous</span>\n  </a>\n  <a class=\"right carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"next\">\n    <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>\n    <span class=\"sr-only\">Next</span>\n  </a>\n</div>\n<!-- //banner -->\n  <div class=\"ads-grid\">\n      <div class=\"container\">\n        <!-- tittle heading -->\n        <h3 class=\"tittle-w3l\">Our Services\n          <span class=\"heading-style\">\n            <i></i>\n            <i></i>\n            <i></i>\n          </span>\n        </h3>\n        <!-- //tittle heading -->\n        <!-- product left -->\n        \n        <!-- //product left -->\n        <!-- product right -->\n        <div class=\"agileinfo-ads-display col-md-12\">\n          <div class=\"wrapper\">\n            <!-- first section (nuts) -->\n            <div class=\"product-sec1\">\n                <h3 class=\"heading-tittle\">WHAT CAN WE DO FOR YOU</h3>\n             \n              <div class=\"col-md-4 product-men homepage\">\n                <div class=\"men-pro-item simpleCart_shelfItem\">\n                  <div class=\"men-thumb-item\">\n                    <img class=\"img-responsive\" src=\"../../assets/images/cp-services-1.jpg\" alt=\"\">\n                   \n                    <span class=\"product-new-top\">1</span>\n                  </div>\n                  <div class=\"item-info-product \">\n                    <p>Wardrobes define your class and choice of everything. Wooden Bells are offered with a choice of openable wardrobes or sliding trendy wardrobes.WardRobes are available in a wide range of finishes including an option of mirrored or glass doors.\n                    </p>\n                    </div>\n                </div>\n              </div>\n\n              <div class=\"col-md-4 product-men homepage\">\n                  <div class=\"men-pro-item simpleCart_shelfItem\">\n                    <div class=\"men-thumb-item\">\n                      <img class=\"img-responsive\" src=\"../../assets/images/cp-services-3.jpg\" alt=\"\">\n                      \n                      <span class=\"product-new-top\">2</span>\n                    </div>\n                    <div class=\"item-info-product \">\n                      <p>The most influential factor in the aesthetic design of home is its cabinetry. We will Customize your cabinetry where your dream closet might live.\n                      </p>\n                      </div>\n                  </div>\n                </div>\n\n                <div class=\"col-md-4 product-men homepage\">\n                    <div class=\"men-pro-item simpleCart_shelfItem\">\n                      <div class=\"men-thumb-item\">\n                        <img class=\"img-responsive\" src=\"../../assets/images/cp-services-2.jpg\" alt=\"\">\n                       \n                        <span class=\"product-new-top\">3</span>\n                      </div>\n                      <div class=\"item-info-product \">\n                        <p>Give your Kitchen an amazing look with the variety range of modular furniture. We offer a choice of high pressure laminates,Glossy, membrane and acrylic finishes for your kitchen cabinetry.\n                             \n                        </p>\n                        </div>\n                    </div>\n                  </div>\n\n                  \n                <div class=\"col-md-4 product-men homepage\">\n                  <div class=\"men-pro-item simpleCart_shelfItem\">\n                    <div class=\"men-thumb-item\">\n                      <img class=\"img-responsive\" src=\"../../assets/images/cp-service-4.jpg\" alt=\"\">\n                    \n                      <span class=\"product-new-top\">4</span>\n                    </div> \n                    <div class=\"item-info-product \">\n                        <p>We offer a full product line of workstations. We combine clean lines and solid components to form sturdy, simple workstations designed to grow as your business grows\n                        </p>\n                        </div>                  \n                  </div>\n                </div>\n              <div class=\"clearfix\"></div>\n            </div>\n          </div>\n        </div>\n        <!-- //product right -->\n      </div>\n    </div>\n    <div class=\"featured-section\" id=\"projects\">\n      <div class=\"container\">\n        <!-- tittle heading -->\n        <h3 class=\"tittle-w3l\">Shop by Category\n          <span class=\"heading-style\">\n            <i></i>\n            <i></i>\n            <i></i>\n          </span>\n        </h3>\n        <!-- //tittle heading -->\n    <angular-image-slider [images]=\"imagesUrl\"></angular-image-slider>\n</div>\n</div>"

/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var HomeComponent = /** @class */ (function () {
    function HomeComponent() {
    }
    HomeComponent.prototype.ngOnInit = function () {
        this.imagesUrl = [
            '../assets/images/1.jpg',
            '../assets/images/2.jpg',
            '../assets/images/3.jpg',
            '../assets/images/4.jpg',
            '../assets/images/5.jpg',
            '../assets/images/6.jpg'
        ];
    };
    HomeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.css */ "./src/app/home/home.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/products-bookshelf/products-bookshelf.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/products-bookshelf/products-bookshelf.component.css ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/products-bookshelf/products-bookshelf.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/products-bookshelf/products-bookshelf.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div class=\"agileinfo-ads-display col-xs-12\">\n    <div class=\"wrapper\">\n      <!-- first section (nuts) -->\n      <div class=\"product-sec1\">\n          <h3 class=\"heading-tittle\">Book Shelves</h3>\n        <div class=\"col-md-4 product-men\">\n          <div class=\"men-pro-item simpleCart_shelfItem\">\n            <div class=\"men-thumb-item\">\n              <img class=\"img-responsive\" src=\"../../assets/images/bookshelve/book1.jpg\" alt=\"\">\n            </div>\n            <div class=\"item-info-product \">\n              <h4>\n               \n              </h4>\n              </div>\n          </div>\n        </div>\n        <div class=\"col-md-4 product-men\">\n          <div class=\"men-pro-item simpleCart_shelfItem\">\n            <div class=\"men-thumb-item\">\n              <img class=\"img-responsive\" src=\"../../assets/images/bookshelve/book.jpg\" alt=\"\">\n            </div>\n            <div class=\"item-info-product \">\n              <h4>\n              \n              </h4>\n              </div>\n          </div>\n        </div>\n  \n       \n        <div class=\"clearfix\"></div>\n      </div>\n    </div>\n  </div>\n  </div>\n  "

/***/ }),

/***/ "./src/app/products-bookshelf/products-bookshelf.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/products-bookshelf/products-bookshelf.component.ts ***!
  \********************************************************************/
/*! exports provided: ProductsBookshelfComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsBookshelfComponent", function() { return ProductsBookshelfComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ProductsBookshelfComponent = /** @class */ (function () {
    function ProductsBookshelfComponent() {
    }
    ProductsBookshelfComponent.prototype.ngOnInit = function () {
    };
    ProductsBookshelfComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-products-bookshelf',
            template: __webpack_require__(/*! ./products-bookshelf.component.html */ "./src/app/products-bookshelf/products-bookshelf.component.html"),
            styles: [__webpack_require__(/*! ./products-bookshelf.component.css */ "./src/app/products-bookshelf/products-bookshelf.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ProductsBookshelfComponent);
    return ProductsBookshelfComponent;
}());



/***/ }),

/***/ "./src/app/products-shoeracks/products-shoeracks.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/products-shoeracks/products-shoeracks.component.css ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/products-shoeracks/products-shoeracks.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/products-shoeracks/products-shoeracks.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div class=\"agileinfo-ads-display col-xs-12\">\n    <div class=\"wrapper\">\n      <!-- first section (nuts) -->\n      <div class=\"product-sec1\">\n          <h3 class=\"heading-tittle\">Shoe Racks</h3>\n        <div class=\"col-md-4 product-men\">\n          <div class=\"men-pro-item simpleCart_shelfItem\">\n            <div class=\"men-thumb-item\">\n              <img class=\"img-responsive\" src=\"../../assets/images/shoe/shoe.jpg\" alt=\"\">\n            </div>\n            <div class=\"item-info-product \">\n              <h4>\n             \n              </h4>\n              </div>\n          </div>\n        </div>\n        <div class=\"col-md-4 product-men\">\n          <div class=\"men-pro-item simpleCart_shelfItem\">\n            <div class=\"men-thumb-item\">\n              <img class=\"img-responsive\" src=\"../../assets/images/shoe/shoerack.jpg\" alt=\"\">\n            </div>\n            <div class=\"item-info-product \">\n              <h4>\n              \n              </h4>\n              </div>\n          </div>\n        </div>\n  \n       \n        <div class=\"clearfix\"></div>\n      </div>\n    </div>\n  </div>\n  </div>\n  "

/***/ }),

/***/ "./src/app/products-shoeracks/products-shoeracks.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/products-shoeracks/products-shoeracks.component.ts ***!
  \********************************************************************/
/*! exports provided: ProductsShoeracksComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsShoeracksComponent", function() { return ProductsShoeracksComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ProductsShoeracksComponent = /** @class */ (function () {
    function ProductsShoeracksComponent() {
    }
    ProductsShoeracksComponent.prototype.ngOnInit = function () {
    };
    ProductsShoeracksComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-products-shoeracks',
            template: __webpack_require__(/*! ./products-shoeracks.component.html */ "./src/app/products-shoeracks/products-shoeracks.component.html"),
            styles: [__webpack_require__(/*! ./products-shoeracks.component.css */ "./src/app/products-shoeracks/products-shoeracks.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ProductsShoeracksComponent);
    return ProductsShoeracksComponent;
}());



/***/ }),

/***/ "./src/app/products-wardrobes/products-wardrobes.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/products-wardrobes/products-wardrobes.component.css ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/products-wardrobes/products-wardrobes.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/products-wardrobes/products-wardrobes.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div class=\"agileinfo-ads-display col-xs-12\">\n    <div class=\"wrapper\">\n      <!-- first section (nuts) -->\n      <div class=\"product-sec1\">\n          <h3 class=\"heading-tittle\">Wardrobes</h3>\n        <div class=\"col-md-4 product-men\">\n          <div class=\"men-pro-item simpleCart_shelfItem\">\n            <div class=\"men-thumb-item\">\n              <img class=\"img-responsive\" src=\"../../assets/images/ward/wardrobes1.jpg\" alt=\"\">\n            </div>\n            <div class=\"item-info-product \">\n              <h4>\n              \n              </h4>\n              </div>\n          </div>\n        </div>\n        <div class=\"col-md-4 product-men\">\n          <div class=\"men-pro-item simpleCart_shelfItem\">\n            <div class=\"men-thumb-item\">\n              <img class=\"img-responsive\" src=\"../../assets/images/ward/wardrobes2.jpg\" alt=\"\">\n            </div>\n            <div class=\"item-info-product \">\n              <h4>\n               \n              </h4>\n              </div>\n          </div>\n        </div>\n  \n        <div class=\"col-md-4 product-men\">\n            <div class=\"men-pro-item simpleCart_shelfItem\">\n              <div class=\"men-thumb-item\">\n                <img class=\"img-responsive\" src=\"../../assets/images/ward/wardrobes3.jpeg\" alt=\"\">\n              </div>\n              <div class=\"item-info-product \">\n                <h4>\n                 \n                </h4>\n                </div>\n            </div>\n          </div>\n\n          <div class=\"col-md-4 product-men\">\n              <div class=\"men-pro-item simpleCart_shelfItem\">\n                <div class=\"men-thumb-item\">\n                  <img class=\"img-responsive\" src=\"../../assets/images/ward/wardrobes3.jpg\" alt=\"\">\n                </div>\n                <div class=\"item-info-product \">\n                  <h4>\n                   \n                  </h4>\n                  </div>\n              </div>\n            </div>\n       \n        <div class=\"clearfix\"></div>\n      </div>\n    </div>\n  </div>\n  </div>\n  "

/***/ }),

/***/ "./src/app/products-wardrobes/products-wardrobes.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/products-wardrobes/products-wardrobes.component.ts ***!
  \********************************************************************/
/*! exports provided: ProductsWardrobesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsWardrobesComponent", function() { return ProductsWardrobesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ProductsWardrobesComponent = /** @class */ (function () {
    function ProductsWardrobesComponent() {
    }
    ProductsWardrobesComponent.prototype.ngOnInit = function () {
    };
    ProductsWardrobesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-products-wardrobes',
            template: __webpack_require__(/*! ./products-wardrobes.component.html */ "./src/app/products-wardrobes/products-wardrobes.component.html"),
            styles: [__webpack_require__(/*! ./products-wardrobes.component.css */ "./src/app/products-wardrobes/products-wardrobes.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ProductsWardrobesComponent);
    return ProductsWardrobesComponent;
}());



/***/ }),

/***/ "./src/app/products/products.component.css":
/*!*************************************************!*\
  !*** ./src/app/products/products.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/products/products.component.html":
/*!**************************************************!*\
  !*** ./src/app/products/products.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"page-head_agile_info_w3l products\">\n\n</div>\n<div class=\"services-breadcrumb\">\n    <div class=\"agile_inner_breadcrumb\">\n      <div class=\"container\">\n        <ul class=\"w3_short\">\n          <li>\n            <a routerLink=\"/\">Home</a>\n            <i>|</i>\n          </li>\n          <li>Products</li>\n        </ul>\n      </div>\n    </div>\n  </div>\n<!-- //banner-2 -->\n\n<div class=\"ads-grid\">\n<div class=\"container\">\n  <!-- tittle heading -->\n  <h3 class=\"tittle-w3l\">Our Products\n    <span class=\"heading-style\">\n      <i></i>\n      <i></i>\n      <i></i>\n    </span>\n  </h3>\n <!-- products left -->\n  <!-- products Right -->\n  <app-productstables></app-productstables>\n  <app-productscots></app-productscots>\n  <app-productswallshelves></app-productswallshelves>\n  <app-products-bookshelf></app-products-bookshelf>\n  <app-products-shoeracks></app-products-shoeracks>\n  <app-products-wardrobes></app-products-wardrobes>\n   <!-- products Right -->\n</div>\n</div>"

/***/ }),

/***/ "./src/app/products/products.component.ts":
/*!************************************************!*\
  !*** ./src/app/products/products.component.ts ***!
  \************************************************/
/*! exports provided: ProductsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductsComponent", function() { return ProductsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ProductsComponent = /** @class */ (function () {
    function ProductsComponent() {
        this.showtables = true;
        this.showcots = true;
    }
    ProductsComponent.prototype.ngOnInit = function () {
    };
    ProductsComponent.prototype.allproductsclick = function () {
        this.showcots = true;
        this.showtables = true;
    };
    ProductsComponent.prototype.tableclick = function () {
        this.showcots = false;
        this.showtables = true;
    };
    ProductsComponent.prototype.cotsclick = function () {
        this.showcots = true;
        this.showtables = false;
    };
    ProductsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-products',
            template: __webpack_require__(/*! ./products.component.html */ "./src/app/products/products.component.html"),
            styles: [__webpack_require__(/*! ./products.component.css */ "./src/app/products/products.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ProductsComponent);
    return ProductsComponent;
}());



/***/ }),

/***/ "./src/app/productscots/productscots.component.css":
/*!*********************************************************!*\
  !*** ./src/app/productscots/productscots.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/productscots/productscots.component.html":
/*!**********************************************************!*\
  !*** ./src/app/productscots/productscots.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n  <div class=\"agileinfo-ads-display col-xs-12\">\n  <div class=\"wrapper\">\n    <!-- first section (nuts) -->\n    <div class=\"product-sec1\">\n        <h3 class=\"heading-tittle\">COTS</h3>\n      <div class=\"col-md-4 product-men\">\n        <div class=\"men-pro-item simpleCart_shelfItem\">\n          <div class=\"men-thumb-item\">\n            <img class=\"img-responsive\" src=\"../../assets/images/Bunk.jpg\" alt=\"\">\n          </div>\n          <div class=\"item-info-product \">\n            <h4>\n              <a href=\"#\">Bunk Beds</a>\n            </h4>\n            </div>\n        </div>\n      </div>\n      <div class=\"col-md-4 product-men\">\n        <div class=\"men-pro-item simpleCart_shelfItem\">\n          <div class=\"men-thumb-item\">\n            <img class=\"img-responsive\" src=\"../../assets/images/cot.jpg\" alt=\"\">\n          </div>\n          <div class=\"item-info-product \">\n            <h4>\n              <a href=\"#\">Cot</a>\n            </h4>\n            </div>\n        </div>\n      </div>\n\n     \n      <div class=\"clearfix\"></div>\n    </div>\n  </div>\n</div>\n</div>\n"

/***/ }),

/***/ "./src/app/productscots/productscots.component.ts":
/*!********************************************************!*\
  !*** ./src/app/productscots/productscots.component.ts ***!
  \********************************************************/
/*! exports provided: ProductscotsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductscotsComponent", function() { return ProductscotsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ProductscotsComponent = /** @class */ (function () {
    function ProductscotsComponent() {
    }
    ProductscotsComponent.prototype.ngOnInit = function () {
    };
    ProductscotsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-productscots',
            template: __webpack_require__(/*! ./productscots.component.html */ "./src/app/productscots/productscots.component.html"),
            styles: [__webpack_require__(/*! ./productscots.component.css */ "./src/app/productscots/productscots.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ProductscotsComponent);
    return ProductscotsComponent;
}());



/***/ }),

/***/ "./src/app/productstables/productstables.component.css":
/*!*************************************************************!*\
  !*** ./src/app/productstables/productstables.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/productstables/productstables.component.html":
/*!**************************************************************!*\
  !*** ./src/app/productstables/productstables.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n\n<!-- product right -->\n<div class=\"agileinfo-ads-display col-md-12\">\n  <div class=\"wrapper\">\n    <!-- first section (nuts) -->\n    <div class=\"product-sec1\">\n        <h3 class=\"heading-tittle\">TABLES</h3>\n      <div class=\"col-md-4 product-men\">\n        <div class=\"men-pro-item simpleCart_shelfItem\">\n          <div class=\"men-thumb-item\">\n            <img class=\"img-responsive\" src=\"../../assets/images/centertable.jpg\" alt=\"\">\n          </div>\n          <div class=\"item-info-product \">\n            <h4>\n              <a href=\"#\">Center Tables</a>\n            </h4>\n            </div>\n        </div>\n      </div>\n      <div class=\"col-md-4 product-men\">\n        <div class=\"men-pro-item simpleCart_shelfItem\">\n          <div class=\"men-thumb-item\">\n            <img class=\"img-responsive\" src=\"../../assets/images/Studytable.jpg\" alt=\"\">\n          </div>\n          <div class=\"item-info-product \">\n            <h4>\n              <a href=\"#\">Study Tables</a>\n            </h4>\n            </div>\n        </div>\n      </div>\n\n      <div class=\"col-md-4 product-men\">\n        <div class=\"men-pro-item simpleCart_shelfItem\">\n          <div class=\"men-thumb-item\">\n            <img class=\"img-responsive\" src=\"../../assets/images/countertable.jpg\" alt=\"\">\n          </div>\n          <div class=\"item-info-product \">\n            <h4>\n              <a href=\"#\">counter Tables</a>\n            </h4>\n            </div>\n        </div>\n      </div>\n\n     \n      <div class=\"clearfix\"></div>\n    </div>\n  </div>\n</div>\n\n</div>"

/***/ }),

/***/ "./src/app/productstables/productstables.component.ts":
/*!************************************************************!*\
  !*** ./src/app/productstables/productstables.component.ts ***!
  \************************************************************/
/*! exports provided: ProductstablesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductstablesComponent", function() { return ProductstablesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ProductstablesComponent = /** @class */ (function () {
    function ProductstablesComponent() {
    }
    ProductstablesComponent.prototype.ngOnInit = function () {
    };
    ProductstablesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-productstables',
            template: __webpack_require__(/*! ./productstables.component.html */ "./src/app/productstables/productstables.component.html"),
            styles: [__webpack_require__(/*! ./productstables.component.css */ "./src/app/productstables/productstables.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ProductstablesComponent);
    return ProductstablesComponent;
}());



/***/ }),

/***/ "./src/app/productswallshelves/productswallshelves.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/productswallshelves/productswallshelves.component.css ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/productswallshelves/productswallshelves.component.html":
/*!************************************************************************!*\
  !*** ./src/app/productswallshelves/productswallshelves.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div class=\"agileinfo-ads-display col-xs-12\">\n    <div class=\"wrapper\">\n      <!-- first section (nuts) -->\n      <div class=\"product-sec1\">\n          <h3 class=\"heading-tittle\">Wallshelves</h3>\n        <div class=\"col-md-4 product-men\">\n          <div class=\"men-pro-item simpleCart_shelfItem\">\n            <div class=\"men-thumb-item\">\n              <img class=\"img-responsive\" src=\"../../assets/images/wallshaves/wallshaves1.jpg\" alt=\"\">\n            </div>\n            <div class=\"item-info-product \">\n              <h4>\n               \n              </h4>\n              </div>\n          </div>\n        </div>\n        <div class=\"col-md-4 product-men\">\n          <div class=\"men-pro-item simpleCart_shelfItem\">\n            <div class=\"men-thumb-item\">\n              <img class=\"img-responsive\" src=\"../../assets/images/wallshaves/wallshaves2.jpg\" alt=\"\">\n            </div>\n            <div class=\"item-info-product \">\n              <h4>\n               \n              </h4>\n              </div>\n          </div>\n        </div>\n\n        <div class=\"col-md-4 product-men\">\n            <div class=\"men-pro-item simpleCart_shelfItem\">\n              <div class=\"men-thumb-item\">\n                <img class=\"img-responsive\" src=\"../../assets/images/wallshaves/wallshaves3.jpg\" alt=\"\">\n              </div>\n              <div class=\"item-info-product \">\n                <h4>\n                \n                </h4>\n                </div>\n            </div>\n          </div>\n\n          \n        <div class=\"col-md-4 product-men\">\n            <div class=\"men-pro-item simpleCart_shelfItem\">\n              <div class=\"men-thumb-item\">\n                <img class=\"img-responsive\" src=\"../../assets/images/wallshaves/wallshaves4.jpg\" alt=\"\">\n              </div>\n              <div class=\"item-info-product \">\n                <h4>\n                \n                </h4>\n                </div>\n            </div>\n          </div>\n  \n  \n       \n        <div class=\"clearfix\"></div>\n      </div>\n    </div>\n  </div>\n  </div>\n  "

/***/ }),

/***/ "./src/app/productswallshelves/productswallshelves.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/productswallshelves/productswallshelves.component.ts ***!
  \**********************************************************************/
/*! exports provided: ProductswallshelvesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductswallshelvesComponent", function() { return ProductswallshelvesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ProductswallshelvesComponent = /** @class */ (function () {
    function ProductswallshelvesComponent() {
    }
    ProductswallshelvesComponent.prototype.ngOnInit = function () {
    };
    ProductswallshelvesComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-productswallshelves',
            template: __webpack_require__(/*! ./productswallshelves.component.html */ "./src/app/productswallshelves/productswallshelves.component.html"),
            styles: [__webpack_require__(/*! ./productswallshelves.component.css */ "./src/app/productswallshelves/productswallshelves.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ProductswallshelvesComponent);
    return ProductswallshelvesComponent;
}());



/***/ }),

/***/ "./src/app/service/service.component.css":
/*!***********************************************!*\
  !*** ./src/app/service/service.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/service/service.component.html":
/*!************************************************!*\
  !*** ./src/app/service/service.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"page-head_agile_info_w3l service\">\n\n  </div>\n  <div class=\"services-breadcrumb\">\n      <div class=\"agile_inner_breadcrumb\">\n        <div class=\"container\">\n          <ul class=\"w3_short\">\n            <li>\n              <a routerLink=\"/\">Home</a>\n              <i>|</i>\n            </li>\n            <li>Services</li>\n          </ul>\n        </div>\n      </div>\n    </div>\n  <!-- //banner-2 -->\n<div class=\"contact agileits\">\n  <div class=\"contact-agileinfo\">\n  \n    <div class=\"contact-right wthree\">\n      <div class=\"col-xs-12 service-text contact-text w3-agileits\">\n        <h4>OUR SERVICES:</h4>\n        <p>We will provide a services for  manufacturing a kitchen cabinets,wardrobes,tables, workstations,office furniture,Cots etc.\n          </p>\n       \n      </div>\n    \n      <div class=\"clearfix\"> </div>\n    </div>\n\n\n  </div>\n</div>\n\n\n<div class=\"ads-grid\">\n  <div class=\"container\">\n    <div class=\"agileinfo-ads-display col-md-12\">\n      <div class=\"wrapper\">\n        <!-- first section (nuts) -->\n        <div class=\"product-sec1\">\n            <h3 class=\"heading-tittle\">WHAT CAN WE DO FOR YOU</h3>\n          <div class=\"col-md-4 product-men\">\n            <div class=\"men-pro-item simpleCart_shelfItem\">\n              <div class=\"men-thumb-item\">\n                <img class=\"img-responsive\" src=\"../../assets/images/S1.jpg\" alt=\"\">\n              </div>\n              <div class=\"item-info-product \">\n                <h4>\n                  <a href=\"#\">Hot Press</a>\n                </h4>\n                </div>\n            </div>\n          </div>\n          <div class=\"col-md-4 product-men\">\n            <div class=\"men-pro-item simpleCart_shelfItem\">\n              <div class=\"men-thumb-item\">\n                <img class=\"img-responsive\" src=\"../../assets/images/S2.jpg\" alt=\"\">\n              </div>\n              <div class=\"item-info-product \">\n                <h4>\n                  <a href=\"#\">Cutting</a>\n                </h4>\n                </div>\n            </div>\n          </div>\n\n          <div class=\"col-md-4 product-men\">\n            <div class=\"men-pro-item simpleCart_shelfItem\">\n              <div class=\"men-thumb-item\">\n                <img class=\"img-responsive\" src=\"../../assets/images/S3.jpg\" alt=\"\">\n              </div>\n              <div class=\"item-info-product \">\n                <h4>\n                  <a href=\"#\">Edge Banding</a>\n                </h4>\n                </div>\n            </div>\n          </div>\n\n          <div class=\"col-md-4 product-men\">\n            <div class=\"men-pro-item simpleCart_shelfItem\">\n              <div class=\"men-thumb-item\">\n                <img class=\"img-responsive\" src=\"../../assets/images/S4.jpg\" alt=\"\">\n              </div>\n              <div class=\"item-info-product \">\n                <h4>\n                  <a href=\"#\">Boaring</a>\n                </h4>\n                </div>\n            </div>\n          </div>\n\n          <div class=\"col-md-4 product-men\">\n            <div class=\"men-pro-item simpleCart_shelfItem\">\n              <div class=\"men-thumb-item\">\n                <img class=\"img-responsive\" src=\"../../assets/images/S5.jpg\" alt=\"\">\n              </div>\n              <div class=\"item-info-product \">\n                <h4>\n                  <a href=\"#\">Planning-Thiknessing-Assembly</a>\n                </h4>\n                </div>\n            </div>\n          </div>\n          <div class=\"clearfix\"></div>\n        </div>\n      </div>\n    </div>\n    <!-- //product right -->\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/service/service.component.ts":
/*!**********************************************!*\
  !*** ./src/app/service/service.component.ts ***!
  \**********************************************/
/*! exports provided: ServiceComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiceComponent", function() { return ServiceComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ServiceComponent = /** @class */ (function () {
    function ServiceComponent() {
    }
    ServiceComponent.prototype.ngOnInit = function () {
    };
    ServiceComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-service',
            template: __webpack_require__(/*! ./service.component.html */ "./src/app/service/service.component.html"),
            styles: [__webpack_require__(/*! ./service.component.css */ "./src/app/service/service.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], ServiceComponent);
    return ServiceComponent;
}());



/***/ }),

/***/ "./src/app/topnavbar/topnavbar.component.css":
/*!***************************************************!*\
  !*** ./src/app/topnavbar/topnavbar.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/topnavbar/topnavbar.component.html":
/*!****************************************************!*\
  !*** ./src/app/topnavbar/topnavbar.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div class=\"header-bot\">\n  <div class=\"header-bot_inner_wthreeinfo_header_mid\">\n    <!-- header-bot-->\n    <div class=\"col-md-4 logo_agile\">\n      <h1>\n        <a routerLink=\"/\">\n          <img class=\"logo\" src=\"../../assets/images/logo.jpg\" alt=\" \">\n        </a>\n      </h1>\n    </div>\n    <!-- header-bot -->\n    <div class=\"col-md-8 header\">\n      <!-- header lists -->\n      <ul>\n        <li>\n          <a class=\"play-icon popup-with-zoom-anim\" routerLink=\"/contact\">\n            <span class=\"fa fa-map-marker\" aria-hidden=\"true\"></span> Post Your Requirement</a>\n        </li>\n        <li>\n          <a class=\"play-icon popup-with-zoom-anim\" routerLink=\"/contact\">\n            <span class=\"fa fa-phone\" aria-hidden=\"true\"></span>+91 7674933669\n          </a>\n        </li>\n        <li>\n          <a routerLink=\"/contact\">\n            <span class=\"fa  fa-envelope-o\" aria-hidden=\"true\"></span>woodenbells@yahoo.com</a>\n        </li>\n      </ul>\n      <!-- //header lists -->\n      <!-- search -->\n      <div class=\"agileits_search\">\n        <form action=\"#\" method=\"post\">\n          <input name=\"Search\" type=\"search\" placeholder=\"How can we help you today?\" required=\"\">\n          <button type=\"submit\" class=\"btn btn-default\" aria-label=\"Left Align\">\n            <span class=\"fa fa-search\" aria-hidden=\"true\"> </span>\n          </button>\n        </form>\n      </div>\n      <!-- //search -->\n      <!-- cart details -->\n      <div class=\"top_nav_right\">\n        <div class=\"social\">\n         \n              <a class=\"icon fb\" href=\"https://www.facebook.com/woodenbells.s.9\" target=\"_blank\">\n                <i class=\"fa fa-facebook\"></i>\n              </a>\n         \n              <a class=\"icon tw\" href=\"https://twitter.com/woodenbellss\" target=\"_blank\">\n                <i class=\"fa fa-twitter\"></i>\n              </a>\n         \n              <a class=\"icon gp\" href=\"#\"target=\"_blank\" >\n                <i class=\"fa fa-google-plus\"></i>\n              </a>\n         \n        </div>\n      </div>\n      <!-- //cart details -->\n      <div class=\"clearfix\"></div>\n    </div>\n    <div class=\"clearfix\"></div>\n  </div>\n</div>\n<!-- shop locator (popup) -->\n<!-- Button trigger modal(shop-locator) -->\n\n\n\n<div class=\"ban-top\">\n  <div class=\"container\">\n    <div class=\"agileits-navi_search\">\n     \n    </div>\n    <div class=\"top_nav_left\">\n      <nav class=\"navbar navbar-default\">\n        <div class=\"container-fluid\">\n          <!-- Brand and toggle get grouped for better mobile display -->\n          <div class=\"navbar-header\">\n            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\"\n                aria-expanded=\"false\">\n              <span class=\"sr-only\">Toggle navigation</span>\n              <span class=\"icon-bar\"></span>\n              <span class=\"icon-bar\"></span>\n              <span class=\"icon-bar\"></span>\n            </button>\n          </div>\n          <!-- Collect the nav links, forms, and other content for toggling -->\n          <div class=\"collapse navbar-collapse menu--shylock\" id=\"bs-example-navbar-collapse-1\">\n            <ul class=\"nav navbar-nav menu__list\">\n              <li class=\"\">\n                <a class=\"nav-stylehead\" routerLink=\"/\">Home\n                  <span class=\"sr-only\">(current)</span>\n                </a>\n              </li>\n              <li class=\"\">\n                <a class=\"nav-stylehead\" routerLink=\"/about\">About Us</a>\n              </li>\n              \n              \n              <li class=\"\">\n                <a class=\"nav-stylehead\" routerLink=\"/service\">Service</a>\n              </li>\n              <!-- <li class=\"\">\n                <a class=\"nav-stylehead\" routerLink=\"/products\">Products</a>\n              </li> -->\n              <li class=\"dropdown\">\n                <a class=\"nav-stylehead dropdown-toggle\" href=\"#\" data-toggle=\"dropdown\">Products\n                  <b class=\"caret\"></b>\n                </a>\n                <ul class=\"dropdown-menu agile_short_dropdown\">\n                  <li>\n                    <a routerLink=\"/productstables\">Tables</a>\n                  </li>\n                  <li>\n                    <a routerLink=\"/productscots\">Cots</a>\n                  </li>\n                  <li>\n                    <a routerLink=\"/productsWallshelves\">Wall shelves</a>\n                  </li>\n                  <li>\n                    <a routerLink=\"/productsBookshelf\">Book shelf's</a>\n                  </li>\n                  <li>\n                    <a routerLink=\"/productsShoeracks\">Shoe racks</a>\n                  </li>\n                  <li>\n                    <a routerLink=\"/productsWardrobes\">Wardrobes</a>\n                  </li>\n                </ul>\n              </li>\n\n              <li class=\"\">\n                <a class=\"nav-stylehead\" routerLink=\"/contact\">Contact</a>\n              </li>\n            </ul>\n          </div>\n        </div>\n      </nav>\n    </div>\n  </div>\n</div>\n<!-- //navigation -->"

/***/ }),

/***/ "./src/app/topnavbar/topnavbar.component.ts":
/*!**************************************************!*\
  !*** ./src/app/topnavbar/topnavbar.component.ts ***!
  \**************************************************/
/*! exports provided: TopnavbarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopnavbarComponent", function() { return TopnavbarComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var TopnavbarComponent = /** @class */ (function () {
    function TopnavbarComponent() {
    }
    TopnavbarComponent.prototype.ngOnInit = function () {
    };
    TopnavbarComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-topnavbar',
            template: __webpack_require__(/*! ./topnavbar.component.html */ "./src/app/topnavbar/topnavbar.component.html"),
            styles: [__webpack_require__(/*! ./topnavbar.component.css */ "./src/app/topnavbar/topnavbar.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], TopnavbarComponent);
    return TopnavbarComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\Moorthi\woodenbellsfull\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map